<?php
$RequestURI = explode('/', $RequestURI[1]);
if (isset($RequestURI[2])) {
	// DISPLAY CITY LISTINGS
} else {
	// DISPLAY PROVINCE LISTINGS
	
	// DISPLAY LINKS TO CITIES
}
?>