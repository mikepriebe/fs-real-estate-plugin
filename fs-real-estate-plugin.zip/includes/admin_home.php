<?php

function fsrep_admin_home() {
	echo '<div class="wrap">
<h2>FireStorm Real Estate Plugin</h2>
<p>&nbsp;</p>
<h3>Version 2.0</h3>
<p>The latest version of the FireStorm Real Estate Plugin can be downloaded from <a href="http://www.firestormplugins.com/plugins/real-estate/" target="_blank">www.firestormplugins.com/plugins/real-estate/</a>.</p>
<h3>Overview</h3>
<p>The FireStorm Real Estate Plugin is an advanced real estate listing system for use with WordPress.</p>
<h3>Developers</h3>
<p>The FireStorm Real Estate Plugin is developed and maintained by <a href="http://www.firestormplugins.com/" target="_blank">FireStorm Plugins</a> which is a division of FireStorm Interactive Inc.. Specializing in WordPress Plugins, FireStorm Interactive creates custom solutions for any type of WordPress application. More information can be found at <a href="http://www.firestorminteractive.com" target="_blank">www.firestorminteractive.com</a>.</p>
<h3>Support and Customization</h3>
<p>For support and customization of the FireStorm Real Estate Plugin, please <a href="http://www.firestormplugins.com/contact/" target="_blank">contact us</a>.</p>
</div>';
}
?>