<?php
	echo fsrep_listings_display('', '', '', '', '', '', $FSREPconfig['GoogleMap'], 0);
?>