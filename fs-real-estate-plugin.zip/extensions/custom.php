<?php
function fsrep_sql_custom() {
	global $wpdb;

	fsrep_sql_insert($wpdb->prefix."fsrep_config", 'config_name', 'MapTypeId', 'config_name, config_value', "'MapTypeId', 'ROADMAP'");
	fsrep_sql_insert($wpdb->prefix."fsrep_config", 'config_name', 'EnableSearchByZip', 'config_name, config_value', "'EnableSearchByZip', 'Yes'");
	fsrep_sql_insert($wpdb->prefix."fsrep_config", 'config_name', 'SearchByZipRadius', 'config_name, config_value', "'SearchByZipRadius', '5,10,15,20,25,50,100,150'");
	fsrep_sql_insert($wpdb->prefix."fsrep_config", 'config_name', 'SearchByZipType', 'config_name, config_value', "'SearchByZipType', 'imperial'");
	fsrep_sql_insert($wpdb->prefix."fsrep_config", 'config_name', 'SearchByZipAdd', 'config_name, config_value', "'SearchByZipAdd', '5'");	
	
}
function fsrep_custom_settings() {
	global $FSREPconfig,$wpdb;
	
	if (isset($_POST['submit'])) {
		$wpdb->query("UPDATE ".$wpdb->prefix."fsrep_config SET config_value = '".addslashes($_POST['MapTypeId'])."' WHERE config_name = 'MapTypeId'");
		$wpdb->query("UPDATE ".$wpdb->prefix."fsrep_config SET config_value = '".addslashes($_POST['EnableSearchByZip'])."' WHERE config_name = 'EnableSearchByZip'");
		$wpdb->query("UPDATE ".$wpdb->prefix."fsrep_config SET config_value = '".addslashes($_POST['SearchByZipRadius'])."' WHERE config_name = 'SearchByZipRadius'");
		$wpdb->query("UPDATE ".$wpdb->prefix."fsrep_config SET config_value = '".addslashes($_POST['SearchByZipType'])."' WHERE config_name = 'SearchByZipType'");
		$wpdb->query("UPDATE ".$wpdb->prefix."fsrep_config SET config_value = '".addslashes($_POST['SearchByZipAdd'])."' WHERE config_name = 'SearchByZipAdd'");

		$sql = mysql_query("SELECT * FROM ".$wpdb->prefix."fsrep_config");
		while($dbfsrepconfig = mysql_fetch_array($sql)) {
			$FSREPconfig[$dbfsrepconfig['config_name']] = $dbfsrepconfig['config_value'];
		}
	}
	echo '<table class="widefat page fixed" cellspacing="0" border="1">
		<thead>
		<tr>
		<th scope="col" class="manage-column" width="200"><b>Custom Settings</b></th>
		<th scope="col" class="manage-column">&nbsp;</th>
		<th scope="col" class="manage-column"><input type="submit" name="submit" class="button-primary" value="Update Settings" style="padding: 3px 8px;"></th>
		</tr>
		</thead>
		<tbody>';
		fsrep_print_admin_selectbox('Google Map Type', 'MapTypeId', $FSREPconfig['MapTypeId'], array('Roadmap' => 'ROADMAP', 'Terrain' => 'TERRAIN', 'Satellite' => 'SATELLITE', 'Hybrid' => 'HYBRID'), '', '');
		fsrep_print_admin_selectbox('Enable Search By Zip', 'EnableSearchByZip', $FSREPconfig['EnableSearchByZip'], array('Yes' => 'Yes', 'No' => 'No'), '', '');
		fsrep_print_admin_selectbox('Search By Zip Units', 'SearchByZipType', $FSREPconfig['SearchByZipType'], array('Miles' => 'imperial', 'Kilometers' => 'metrics'), '', '');
		fsrep_print_admin_input('Search By Zip Default Radius', 'SearchByZipRadius', $FSREPconfig['SearchByZipRadius'], 10, 'Separate By Commas');
		fsrep_print_admin_input('Search By Zip Buffer', 'SearchByZipAdd', $FSREPconfig['SearchByZipAdd'], 10, 'Must Be Numerical');
	echo '</tbody></table>';
}
function fsrep_custom_search() {
	global $FSREPconfig;
	if ($FSREPconfig['SearchByZipType'] == 'imperial') { $Units = ' Miles'; } else { $Units = ' Kms'; }
	echo '<div id="fsrepws-input"><div id="fsrepws-input-title">Radius:</div>';
	echo '<select name="fsrepw-search-radius">';
	$Radius = explode(',',$FSREPconfig['SearchByZipRadius']);
	foreach ($Radius as $Radius => $Value) {
		echo '<option value="'.$Value.'">'.$Value.' '.$Units.'</option>';
	}
	echo '</select></div>';
	echo '<div id="fsrepws-input"><div id="fsrepws-input-title">Zip Code</div><input type="text" name="fsrepw-search-zip" id="fsrepw-search-zip" value=""></div>';
}
function fsrep_custom_search_results($SearchSQL) {
	global $wpdb,$FSREPconfig,$_POST;
	
	$SearchRadius = $_POST['fsrepw-search-radius'] + $FSREPconfig['SearchByZipAdd'];
	$GroupBy = explode('GROUP BY',$SearchSQL);
	
	$SearchResults = $wpdb->get_results($SearchSQL);
	$IDinBounds = '';
	foreach ($SearchResults as $Results) {
		$IDinBounds .= str_replace(' ','',str_replace('-','',$Results->listing_address_postal)).'|';
	}
	$XMLUrl = 'http://maps.googleapis.com/maps/api/distancematrix/xml?origins='.$_POST['fsrepw-search-zip'].'&destinations='.substr($IDinBounds, 0, -1).'&sensor=false&units='.$FSREPconfig['SearchByZipType'];
	$XMLContents = file_get_contents($XMLUrl);
	$XML = new SimpleXMLElement($XMLContents);
	
	$i = 0;
	$InIDs = '';
	foreach ($SearchResults as $ListingIDs) {
		if (substr($XML->row->element[$i]->distance->text, -3) == ' ft') { $XML->row->element[$i]->distance->text = 0; }
		$Distance = str_replace(' mi','',str_replace(' km','',$XML->row->element[$i]->distance->text));
		if ($Distance <= $SearchRadius) { 
			$InIDs .= $ListingIDs->listing_id.',';
		}
		$i++;
	}
	
	$FSREPSearch['query'] = "SELECT * FROM ".$wpdb->prefix."fsrep_listings WHERE listing_id IN(".substr($InIDs, 0, -1).") GROUP BY ".$GroupBy[1];

	$CityName = $wpdb->get_var("SELECT city_name FROM ".$wpdb->prefix."fsrep_cities WHERE city_id = ".$_POST['fsrepw-search-city']);
	$ProvinceName = $wpdb->get_var("SELECT province_name FROM ".$wpdb->prefix."fsrep_provinces WHERE province_id = ".$_POST['fsrepw-search-province']);
	$Coords = google_geocoder($CityName.' '.$ProvinceName.' '.$_POST['fsrepw-search-zip'].' ', $FSREPconfig['GoogleMapAPI']);
	$FSREPSearch['glong'] = $Coords[0];
	$FSREPSearch['glat'] = $Coords[1];
	$FSREPSearch['gzoom'] = 11;

	return $FSREPSearch;
}
function fsrep_custom_search_ids() {
	
}
function fsrep_custom_map_js() {

	echo '';
	
}



?>
